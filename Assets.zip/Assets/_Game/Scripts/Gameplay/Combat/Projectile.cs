using System.Collections.Generic;
using DienGame.Gameplay.Enemy;
using UnityEngine;

namespace DienGame.Gameplay.Combat
{
    public sealed class Projectile : MonoBehaviour
    {
        [Header("Lifetime")]

        [SerializeField, Min(0.1f)]
        private float lifeTime = 5f;

        [Header("Hit")]

        [SerializeField, Min(0.01f)]
        private float hitDistance = 0.15f;

        private Vector2 _direction;

        private float _moveSpeed;

        private float _damage;

        private float _remainingLife;

        private bool _initialized;

        // =========================================
        // PIERCING
        // =========================================

        private int _remainingPierces;

        // Tránh cùng một viên đạn damage cùng một Enemy
        // nhiều lần nếu Enemy có nhiều Collider2D.
        private readonly HashSet<EnemyHealth>
            _hitEnemies = new();

        private void OnEnable()
        {
            _remainingLife =
                lifeTime;

            _hitEnemies.Clear();
        }

        private void Update()
        {
            if (!_initialized)
            {
                return;
            }

            Move();

            UpdateLifetime();
        }

        // =========================================
        // INITIALIZE
        // =========================================

        public void Initialize(
            Vector2 direction,
            float speed,
            float damage,
            int additionalPierceCount = 0)
        {
            if (
                direction.sqrMagnitude <=
                0.0001f
            )
            {
                Destroy(
                    gameObject
                );

                return;
            }

            _direction =
                direction.normalized;

            _moveSpeed =
                Mathf.Max(
                    0f,
                    speed
                );

            _damage =
                Mathf.Max(
                    0f,
                    damage
                );

            _remainingPierces =
                Mathf.Max(
                    0,
                    additionalPierceCount
                );

            _remainingLife =
                lifeTime;

            _hitEnemies.Clear();

            _initialized =
                true;
        }

        // =========================================
        // MOVE
        // =========================================

        private void Move()
        {
            Vector2 movement =
                _direction *
                _moveSpeed *
                Time.deltaTime;

            transform.position +=
                (Vector3)movement;
        }

        // =========================================
        // LIFETIME
        // =========================================

        private void UpdateLifetime()
        {
            _remainingLife -=
                Time.deltaTime;

            if (_remainingLife > 0f)
            {
                return;
            }

            Destroy(
                gameObject
            );
        }

        // =========================================
        // HIT ENEMY
        // =========================================

        private void OnTriggerEnter2D(
            Collider2D other)
        {
            EnemyHealth enemyHealth =
                other.GetComponentInParent<
                    EnemyHealth
                >();

            if (enemyHealth == null)
            {
                return;
            }

            if (enemyHealth.IsDead)
            {
                return;
            }

            // Một projectile chỉ được gây damage
            // một lần lên cùng một Enemy.
            if (_hitEnemies.Contains(enemyHealth))
            {
                return;
            }

            _hitEnemies.Add(
                enemyHealth
            );

            enemyHealth.TakeDamage(
                _damage
            );

            // Còn lượt xuyên:
            // tiếp tục bay.
            if (_remainingPierces > 0)
            {
                _remainingPierces--;

                return;
            }

            // Hết lượt xuyên.
            Destroy(
                gameObject
            );
        }
    }
}