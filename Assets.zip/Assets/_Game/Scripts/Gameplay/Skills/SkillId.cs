namespace DienGame.Gameplay.Skills
{
    public enum SkillId
    {
        None = 0,

        // Marksman - Bullet Upgrades
        PiercingBullet = 100,

        // Marksman - Class Skills
        ThunderBullet = 200,
        CombatDrone = 201,
    }
}