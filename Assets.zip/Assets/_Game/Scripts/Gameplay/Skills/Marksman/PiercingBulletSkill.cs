namespace DienGame.Gameplay.Skills.Marksman
{
    public static class PiercingBulletSkill
    {
        public static int GetAdditionalPierceCount(
            int level)
        {
            return level switch
            {
                <= 0 => 0,
                1 => 1,
                2 => 2,
                3 => 3,
                4 => 4,
                _ => 5,
            };
        }

        public static string GetDescription(
            int level)
        {
            return level switch
            {
                1 => "Đạn xuyên thêm 1 kẻ địch.",

                2 => "Đạn xuyên thêm 2 kẻ địch.",

                3 => "Đạn xuyên thêm 3 kẻ địch.",

                4 => "Đạn xuyên thêm 4 kẻ địch.",

                5 => "Đạn xuyên thêm 5 kẻ địch.",

                _ => "Đạn có khả năng xuyên qua nhiều kẻ địch.",
            };
        }
    }
}