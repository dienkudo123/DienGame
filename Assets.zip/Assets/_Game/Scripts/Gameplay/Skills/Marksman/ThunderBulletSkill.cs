namespace DienGame.Gameplay.Skills.Marksman
{
    public static class ThunderBulletSkill
    {
        public static int GetShotsPerTrigger(
            int level)
        {
            return level switch
            {
                <= 0 => int.MaxValue,
                1 => 8,
                2 => 7,
                3 => 6,
                4 => 5,
                _ => 4,
            };
        }

        public static int GetChainTargets(
            int level)
        {
            return level switch
            {
                <= 0 => 0,
                1 => 2,
                2 => 3,
                3 => 4,
                4 => 5,
                _ => 6,
            };
        }

        public static float GetDamageMultiplier(
            int level)
        {
            return level switch
            {
                <= 0 => 0f,
                1 => 0.45f,
                2 => 0.50f,
                3 => 0.55f,
                4 => 0.60f,
                _ => 0.70f,
            };
        }

        public static float GetChainRange(
            int level)
        {
            return level >= 4
                ? 4f
                : 3.25f;
        }

        public static string GetDescription(
            int level)
        {
            return level switch
            {
                1 =>
                    "Mỗi 8 phát bắn, phóng sét lan sang tối đa 2 kẻ địch.",

                2 =>
                    "Kích hoạt mỗi 7 phát và sét lan tối đa 3 mục tiêu.",

                3 =>
                    "Kích hoạt mỗi 6 phát, lan 4 mục tiêu và tăng sát thương sét.",

                4 =>
                    "Kích hoạt mỗi 5 phát, lan 5 mục tiêu với phạm vi lớn hơn.",

                5 =>
                    "Kích hoạt mỗi 4 phát, lan 6 mục tiêu và gây 70% sát thương đòn bắn.",

                _ =>
                    "Đạn tích điện tạo chuỗi sét giữa các kẻ địch.",
            };
        }
    }
}