using System.Collections.Generic;
using DienGame.Gameplay.Enemy;
using DienGame.Gameplay.Player;
using UnityEngine;

namespace DienGame.Gameplay.Skills.Marksman
{
    [RequireComponent(typeof(PlayerSkillManager))]
    public sealed class MarksmanSkillController : MonoBehaviour
    {
        // =========================================
        // DRONE VISUAL
        // =========================================

        [Header("Drone Normal Animation")]

        [SerializeField]
        private Sprite[] normalDroneFrames;

        [Header("Drone MAX Animation")]

        [SerializeField]
        private Sprite[] maxDroneFrames;

        [Header("Drone Animation")]

        [SerializeField, Min(1f)]
        private float droneAnimationFPS = 8f;

        [SerializeField]
        private int droneSortingOrder = 20;

        // =========================================
        // REFERENCES
        // =========================================

        private PlayerSkillManager _skillManager;

        private PlayerAutoAttack _autoAttack;

        // =========================================
        // DRONE RUNTIME
        // =========================================

        private readonly List<DroneRuntime>
            _drones = new();

        private float _droneOrbitAngle;

        private int _lastDroneLevel = -1;

        // =========================================
        // THUNDER RUNTIME
        // =========================================

        private int _normalShotCounter;

        // =========================================
        // UNITY
        // =========================================

        private void Awake()
        {
            _skillManager =
                GetComponent<PlayerSkillManager>();

            _autoAttack =
                GetComponent<PlayerAutoAttack>();
        }

        private void OnEnable()
        {
            if (_skillManager != null)
            {
                _skillManager.SkillLevelChanged +=
                    OnSkillLevelChanged;
            }
        }

        private void OnDisable()
        {
            if (_skillManager != null)
            {
                _skillManager.SkillLevelChanged -=
                    OnSkillLevelChanged;
            }
        }

        private void Start()
        {
            RefreshDroneSystem();
        }

        private void Update()
        {
            UpdateDrones();
        }

        // =========================================
        // NORMAL SHOT NOTIFICATION
        // =========================================

        public void NotifyNormalShot(
            Transform primaryTarget,
            float baseDamage)
        {
            if (
                _skillManager == null ||
                primaryTarget == null
            )
            {
                return;
            }

            int thunderLevel =
                _skillManager.GetSkillLevel(
                    SkillId.ThunderBullet
                );

            if (thunderLevel <= 0)
            {
                return;
            }

            _normalShotCounter++;

            int requiredShots =
                ThunderBulletSkill
                    .GetShotsPerTrigger(
                        thunderLevel
                    );

            if (
                _normalShotCounter <
                requiredShots
            )
            {
                return;
            }

            _normalShotCounter = 0;

            TriggerChainLightning(
                primaryTarget,
                baseDamage,
                thunderLevel
            );
        }

        // =========================================
        // THUNDER BULLET
        // =========================================

        private void TriggerChainLightning(
            Transform primaryTarget,
            float baseDamage,
            int level)
        {
            EnemyHealth firstEnemy =
                primaryTarget.GetComponentInParent<
                    EnemyHealth
                >();

            if (
                firstEnemy == null ||
                firstEnemy.IsDead
            )
            {
                return;
            }

            int maxTargets =
                ThunderBulletSkill
                    .GetChainTargets(
                        level
                    );

            float chainRange =
                ThunderBulletSkill
                    .GetChainRange(
                        level
                    );

            float damage =
                baseDamage *
                ThunderBulletSkill
                    .GetDamageMultiplier(
                        level
                    );

            var hitEnemies =
                new HashSet<EnemyHealth>();

            EnemyHealth currentEnemy =
                firstEnemy;

            Vector3 previousPosition =
                transform.position;

            for (
                int i = 0;
                i < maxTargets &&
                currentEnemy != null;
                i++
            )
            {
                DrawTracer(
                    previousPosition,
                    currentEnemy.transform.position,
                    0.10f,
                    0.06f
                );

                currentEnemy.TakeDamage(
                    damage
                );

                hitEnemies.Add(
                    currentEnemy
                );

                previousPosition =
                    currentEnemy.transform.position;

                currentEnemy =
                    FindNearestEnemy(
                        previousPosition,
                        chainRange,
                        hitEnemies
                    );
            }
        }

        // =========================================
        // SKILL LEVEL CHANGED
        // =========================================

        private void OnSkillLevelChanged(
            SkillId skillId,
            int level)
        {
            if (
                skillId ==
                SkillId.CombatDrone
            )
            {
                RefreshDroneSystem();
            }

            if (
                skillId ==
                SkillId.ThunderBullet
            )
            {
                _normalShotCounter = 0;
            }
        }

        // =========================================
        // REFRESH DRONE
        // =========================================

        private void RefreshDroneSystem()
        {
            if (_skillManager == null)
            {
                return;
            }

            int level =
                _skillManager.GetSkillLevel(
                    SkillId.CombatDrone
                );

            if (
                level ==
                _lastDroneLevel
            )
            {
                return;
            }

            _lastDroneLevel =
                level;

            RebuildDrones(
                level
            );
        }

        // =========================================
        // REBUILD
        // =========================================

        private void RebuildDrones(
            int level)
        {
            DestroyAllDrones();

            int droneCount =
                CombatDroneSkill
                    .GetDroneCount(
                        level
                    );

            if (droneCount <= 0)
            {
                return;
            }

            bool maxForm =
                CombatDroneSkill
                    .IsMaxForm(
                        level
                    );

            for (
                int i = 0;
                i < droneCount;
                i++
            )
            {
                CreateDrone(
                    level,
                    maxForm
                );
            }
        }

        // =========================================
        // CREATE DRONE
        // =========================================

        private void CreateDrone(
            int level,
            bool maxForm)
        {
            GameObject droneObject =
                new GameObject(
                    maxForm
                        ? "EliteCombatDrone"
                        : "CombatDrone"
                );

            droneObject.transform.SetParent(
                transform,
                false
            );

            SpriteRenderer renderer =
                droneObject.AddComponent<
                    SpriteRenderer
                >();

            renderer.sortingOrder =
                droneSortingOrder;

            CombatDroneVisual visual =
                droneObject.AddComponent<
                    CombatDroneVisual
                >();

            Sprite[] frames =
                maxForm
                    ? maxDroneFrames
                    : normalDroneFrames;

            visual.Initialize(
                frames,
                droneAnimationFPS,
                CombatDroneSkill
                    .GetVisualScale(level)
            );

            DroneRuntime runtime =
                new DroneRuntime
                {
                    Transform =
                        droneObject.transform,

                    Visual =
                        visual,

                    AttackTimer =
                        Random.Range(
                            0f,
                            CombatDroneSkill
                                .GetAttackInterval(
                                    level
                                )
                        )
                };

            _drones.Add(
                runtime
            );
        }

        // =========================================
        // DESTROY
        // =========================================

        private void DestroyAllDrones()
        {
            for (
                int i = 0;
                i < _drones.Count;
                i++
            )
            {
                DroneRuntime drone =
                    _drones[i];

                if (
                    drone != null &&
                    drone.Transform != null
                )
                {
                    Destroy(
                        drone.Transform.gameObject
                    );
                }
            }

            _drones.Clear();
        }

        // =========================================
        // UPDATE DRONES
        // =========================================

        private void UpdateDrones()
        {
            if (_skillManager == null)
            {
                return;
            }

            int level =
                _skillManager.GetSkillLevel(
                    SkillId.CombatDrone
                );

            if (level <= 0)
            {
                return;
            }

            if (
                level !=
                _lastDroneLevel
            )
            {
                RefreshDroneSystem();
            }

            if (_drones.Count == 0)
            {
                return;
            }

            _droneOrbitAngle +=
                CombatDroneSkill
                    .GetOrbitSpeed(level) *
                Time.deltaTime;

            for (
                int i = 0;
                i < _drones.Count;
                i++
            )
            {
                DroneRuntime drone =
                    _drones[i];

                if (
                    drone == null ||
                    drone.Transform == null
                )
                {
                    continue;
                }

                UpdateDronePosition(
                    drone,
                    i,
                    level
                );

                UpdateDroneAttack(
                    drone,
                    level
                );
            }
        }

        // =========================================
        // ORBIT
        // =========================================

        private void UpdateDronePosition(
            DroneRuntime drone,
            int index,
            int level)
        {
            float spacing =
                360f /
                Mathf.Max(
                    1,
                    _drones.Count
                );

            float angle =
                _droneOrbitAngle +
                spacing *
                index;

            float radians =
                angle *
                Mathf.Deg2Rad;

            float radius =
                CombatDroneSkill
                    .GetOrbitRadius(
                        level
                    );

            drone.Transform.localPosition =
                new Vector3(
                    Mathf.Cos(radians) *
                    radius,

                    Mathf.Sin(radians) *
                    radius,

                    0f
                );
        }

        // =========================================
        // DRONE ATTACK
        // =========================================

        private void UpdateDroneAttack(
            DroneRuntime drone,
            int level)
        {
            drone.AttackTimer -=
                Time.deltaTime;

            if (drone.AttackTimer > 0f)
            {
                return;
            }

            float range =
                CombatDroneSkill
                    .GetAttackRange(
                        level
                    );

            EnemyHealth target =
                FindNearestEnemy(
                    drone.Transform.position,
                    range,
                    null
                );

            if (target == null)
            {
                return;
            }

            // Đặt MuzzlePoint về phía mục tiêu.
            if (drone.Visual != null)
            {
                drone.Visual.AimAt(
                    target.transform.position
                );
            }

            float playerDamage =
                _autoAttack != null
                    ? _autoAttack.AttackDamage
                    : 20f;

            float damage =
                playerDamage *
                CombatDroneSkill
                    .GetDamageMultiplier(
                        level
                    );

            FireDroneWeapon(
                drone,
                target,
                damage,
                level
            );

            drone.AttackTimer =
                CombatDroneSkill
                    .GetAttackInterval(
                        level
                    );
        }

        // =========================================
        // FIRE DRONE
        // =========================================

        private void FireDroneWeapon(
            DroneRuntime drone,
            EnemyHealth target,
            float damage,
            int level)
        {
            if (
                drone == null ||
                drone.Transform == null ||
                target == null
            )
            {
                return;
            }

            Vector3 muzzlePosition =
                drone.Visual != null
                    ? drone.Visual.MuzzlePosition
                    : drone.Transform.position;

            bool maxForm =
                CombatDroneSkill
                    .IsMaxForm(
                        level
                    );

            // Drone thường:
            // một đường đạn từ đầu nòng.
            if (!maxForm)
            {
                DrawTracer(
                    muzzlePosition,
                    target.transform.position,
                    0.07f,
                    0.045f
                );

                target.TakeDamage(
                    damage
                );

                return;
            }

            // =====================================
            // ELITE DRONE Lv5
            // =====================================
            //
            // Một Drone nhưng có 2 nòng.
            //
            // Hiện tại dùng 2 tracer song song.
            // Sau này thay bằng Projectile thật.

            Vector3 direction =
                (
                    target.transform.position -
                    muzzlePosition
                ).normalized;

            Vector3 perpendicular =
                new Vector3(
                    -direction.y,
                    direction.x,
                    0f
                );

            const float barrelSpacing =
                0.07f;

            Vector3 muzzleA =
                muzzlePosition +
                perpendicular *
                barrelSpacing;

            Vector3 muzzleB =
                muzzlePosition -
                perpendicular *
                barrelSpacing;

            DrawTracer(
                muzzleA,
                target.transform.position,
                0.10f,
                0.05f
            );

            DrawTracer(
                muzzleB,
                target.transform.position,
                0.10f,
                0.05f
            );

            // Damage chỉ tính một lần.
            // Hai tracer chỉ là visual 2 nòng.
            target.TakeDamage(
                damage
            );
        }

        // =========================================
        // FIND ENEMY
        // =========================================

        private static EnemyHealth FindNearestEnemy(
            Vector3 origin,
            float maxRange,
            HashSet<EnemyHealth> excluded)
        {
            EnemyHealth[] enemies =
                FindObjectsByType<
                    EnemyHealth
                >(
                    FindObjectsSortMode.None
                );

            EnemyHealth nearestEnemy =
                null;

            float nearestDistanceSquared =
                maxRange *
                maxRange;

            foreach (
                EnemyHealth enemy
                in enemies
            )
            {
                if (
                    enemy == null ||
                    enemy.IsDead
                )
                {
                    continue;
                }

                if (
                    excluded != null &&
                    excluded.Contains(enemy)
                )
                {
                    continue;
                }

                float distanceSquared =
                    (
                        enemy.transform.position -
                        origin
                    ).sqrMagnitude;

                if (
                    distanceSquared >=
                    nearestDistanceSquared
                )
                {
                    continue;
                }

                nearestDistanceSquared =
                    distanceSquared;

                nearestEnemy =
                    enemy;
            }

            return nearestEnemy;
        }

        // =========================================
        // TRACER
        // =========================================

        private static void DrawTracer(
            Vector3 from,
            Vector3 to,
            float duration,
            float width)
        {
            GameObject tracer =
                new GameObject(
                    "SkillTracer"
                );

            LineRenderer line =
                tracer.AddComponent<
                    LineRenderer
                >();

            line.positionCount = 2;

            line.useWorldSpace = true;

            line.SetPosition(
                0,
                from
            );

            line.SetPosition(
                1,
                to
            );

            line.startWidth =
                width;

            line.endWidth =
                width * 0.35f;

            Shader shader =
                Shader.Find(
                    "Sprites/Default"
                );

            if (shader != null)
            {
                line.material =
                    new Material(
                        shader
                    );
            }

            line.sortingOrder =
                30;

            Destroy(
                tracer,
                duration
            );
        }

        // =========================================
        // CLEANUP
        // =========================================

        private void OnDestroy()
        {
            DestroyAllDrones();
        }

        // =========================================
        // RUNTIME DATA
        // =========================================

        private sealed class DroneRuntime
        {
            public Transform Transform;

            public CombatDroneVisual Visual;

            public float AttackTimer;
        }
    }
}