using DienGame.Gameplay.Combat;
using DienGame.Gameplay.Skills;
using DienGame.Gameplay.Skills.Marksman;
using UnityEngine;

namespace DienGame.Gameplay.Player
{
    [RequireComponent(typeof(PlayerTargeting))]
    [RequireComponent(typeof(PlayerShootVisualSignal))]
    [RequireComponent(typeof(PlayerSkillManager))]
    [RequireComponent(typeof(MarksmanSkillController))]
    public sealed class PlayerAutoAttack : MonoBehaviour
    {
        // =========================================
        // REFERENCES
        // =========================================

        [Header("References")]

        [SerializeField]
        private PlayerCharacter playerCharacter;

        [SerializeField]
        private GameObject projectilePrefab;

        // =========================================
        // PROJECTILE
        // =========================================

        [Header("Projectile")]

        [SerializeField, Min(0f)]
        private float projectileSpawnDistance = 0.6f;

        [SerializeField, Min(0.1f)]
        private float projectileSpeed = 10f;

        // =========================================
        // FALLBACK
        // =========================================

        [Header("Fallback Stats")]

        [SerializeField, Min(0f)]
        private float attackDamage = 20f;

        [SerializeField, Min(0.01f)]
        private float attackInterval = 1f;

        // =========================================
        // RUNTIME
        // =========================================

        private PlayerTargeting _targeting;

        private PlayerShootVisualSignal
            _shootVisualSignal;

        private PlayerSkillManager
            _skillManager;

        private MarksmanSkillController
            _marksmanSkills;

        private float _attackTimer;

        // =========================================
        // PUBLIC
        // =========================================

        public float AttackDamage =>
            playerCharacter != null
                ? playerCharacter.Damage
                : attackDamage;

        public float AttackInterval =>
            playerCharacter != null
                ? playerCharacter.AttackInterval
                : attackInterval;

        // =========================================
        // UNITY
        // =========================================

        private void Awake()
        {
            _targeting =
                GetComponent<PlayerTargeting>();

            _shootVisualSignal =
                GetComponent<
                    PlayerShootVisualSignal
                >();

            _skillManager =
                GetComponent<
                    PlayerSkillManager
                >();

            _marksmanSkills =
                GetComponent<
                    MarksmanSkillController
                >();

            if (playerCharacter == null)
            {
                playerCharacter =
                    GetComponent<
                        PlayerCharacter
                    >();
            }
        }

        private void Update()
        {
            UpdateAttackTimer();

            TryAttack();
        }

        // =========================================
        // TIMER
        // =========================================

        private void UpdateAttackTimer()
        {
            if (_attackTimer <= 0f)
            {
                return;
            }

            _attackTimer -=
                Time.deltaTime;

            if (_attackTimer < 0f)
            {
                _attackTimer = 0f;
            }
        }

        // =========================================
        // ATTACK
        // =========================================

        private void TryAttack()
        {
            Transform target =
                _targeting != null
                    ? _targeting.CurrentTarget
                    : null;

            if (target == null)
            {
                return;
            }

            if (_attackTimer > 0f)
            {
                return;
            }

            Shoot(
                target
            );

            _attackTimer =
                AttackInterval;
        }

        // =========================================
        // SHOOT
        // =========================================

        private void Shoot(
            Transform target)
        {
            if (projectilePrefab == null)
            {
                Debug.LogError(
                    "PlayerAutoAttack: " +
                    "Chưa gán Projectile Prefab.",
                    this
                );

                return;
            }

            Vector2 direction =
                (Vector2)target.position -
                (Vector2)transform.position;

            if (
                direction.sqrMagnitude <=
                0.0001f
            )
            {
                return;
            }

            direction.Normalize();

            Vector2 spawnPosition =
                (Vector2)transform.position +
                direction *
                projectileSpawnDistance;

            GameObject projectileObject =
                Instantiate(
                    projectilePrefab,
                    spawnPosition,
                    Quaternion.identity
                );

            if (
                projectileObject.TryGetComponent(
                    out Projectile projectile
                )
            )
            {
                int piercingLevel =
                    _skillManager != null
                        ? _skillManager.GetSkillLevel(
                            SkillId.PiercingBullet
                        )
                        : 0;

                int additionalPierces =
                    PiercingBulletSkill
                        .GetAdditionalPierceCount(
                            piercingLevel
                        );

                projectile.Initialize(
                    direction,
                    projectileSpeed,
                    AttackDamage,
                    additionalPierces
                );
            }
            else
            {
                Debug.LogError(
                    "Projectile Prefab không có " +
                    "component Projectile.",
                    projectileObject
                );
            }

            // Báo cho hệ skill rằng Player
            // vừa bắn một phát thường.
            if (_marksmanSkills != null)
            {
                _marksmanSkills.NotifyNormalShot(
                    target,
                    AttackDamage
                );
            }

            if (_shootVisualSignal != null)
            {
                _shootVisualSignal.TriggerShot();
            }
        }

        // =========================================
        // COMPATIBILITY
        // =========================================

        public void MultiplyAttackDamage(
            float multiplier)
        {
            if (multiplier <= 0f)
            {
                return;
            }

            if (playerCharacter != null)
            {
                playerCharacter.MultiplyDamage(
                    multiplier
                );

                return;
            }

            attackDamage *=
                multiplier;
        }

        public void MultiplyProjectileSpeed(
            float multiplier)
        {
            if (multiplier <= 0f)
            {
                return;
            }

            projectileSpeed *=
                multiplier;
        }
    }
}