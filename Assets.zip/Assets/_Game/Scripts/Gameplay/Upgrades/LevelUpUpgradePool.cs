using System.Collections.Generic;
using DienGame.Gameplay.Skills;
using DienGame.Gameplay.Skills.Marksman;
using UnityEngine;

namespace DienGame.Gameplay.Upgrades
{
    public static class LevelUpUpgradePool
    {
        public static List<UpgradeDefinition>
            GetRandomOptions(
                int count,
                PlayerSkillManager skillManager)
        {
            var available =
                new List<UpgradeDefinition>();

            if (skillManager == null)
            {
                return available;
            }

            // =====================================
            // ĐẠN XUYÊN PHÁ
            // =====================================

            AddSkill(
                available,
                skillManager,
                SkillId.PiercingBullet,
                "Đạn Xuyên Phá",
                PiercingBulletSkill
                    .GetDescription
            );

            // =====================================
            // LÔI ĐẠN
            // =====================================

            AddSkill(
                available,
                skillManager,
                SkillId.ThunderBullet,
                "Lôi Đạn",
                ThunderBulletSkill
                    .GetDescription
            );

            // =====================================
            // DRONE
            // =====================================

            AddSkill(
                available,
                skillManager,
                SkillId.CombatDrone,
                "Drone Chiến Đấu",
                CombatDroneSkill
                    .GetDescription
            );

            // =====================================
            // RANDOM
            // =====================================

            var result =
                new List<UpgradeDefinition>();

            count =
                Mathf.Min(
                    count,
                    available.Count
                );

            for (
                int i = 0;
                i < count;
                i++
            )
            {
                int index =
                    Random.Range(
                        0,
                        available.Count
                    );

                result.Add(
                    available[index]
                );

                available.RemoveAt(
                    index
                );
            }

            return result;
        }

        // =========================================
        // ADD SKILL
        // =========================================

        private static void AddSkill(
            List<UpgradeDefinition> available,
            PlayerSkillManager skillManager,
            SkillId skillId,
            string skillName,
            System.Func<int, string>
                descriptionFactory)
        {
            if (
                !skillManager.CanUpgrade(
                    skillId
                )
            )
            {
                return;
            }

            int nextLevel =
                skillManager.GetSkillLevel(
                    skillId
                ) + 1;

            available.Add(
                new UpgradeDefinition(
                    skillId,

                    $"{skillName} " +
                    $"{GetRomanLevel(nextLevel)}",

                    descriptionFactory(
                        nextLevel
                    )
                )
            );
        }

        // =========================================
        // LEVEL TEXT
        // =========================================

        private static string GetRomanLevel(
            int level)
        {
            return level switch
            {
                1 => "I",
                2 => "II",
                3 => "III",
                4 => "IV",
                5 => "V",
                _ => level.ToString(),
            };
        }
    }
}