using DienGame.Gameplay.Enemy;
using UnityEngine;

namespace DienGame.Gameplay.Combat
{
    public sealed class Projectile : MonoBehaviour
    {
        [SerializeField]
        [Min(0.1f)]
        private float moveSpeed = 10f;

        [SerializeField]
        [Min(0.01f)]
        private float hitDistance = 0.15f;

        private Transform _target;
        private float _damage;

        public void Initialize(
            Transform target,
            float damage)
        {
            _target = target;
            _damage = damage;
        }

        private void Update()
        {
            if (_target == null)
            {
                Destroy(gameObject);
                return;
            }

            MoveToTarget();
        }

        private void MoveToTarget()
        {
            Vector3 targetPosition =
                _target.position;

            transform.position =
                Vector3.MoveTowards(
                    transform.position,
                    targetPosition,
                    moveSpeed * Time.deltaTime
                );

            float distance =
                Vector2.Distance(
                    transform.position,
                    targetPosition
                );

            if (distance <= hitDistance)
            {
                HitTarget();
            }
        }

        private void HitTarget()
        {
            if (
                _target != null &&
                _target.TryGetComponent(
                    out EnemyHealth enemyHealth)
            )
            {
                enemyHealth.TakeDamage(_damage);
            }

            Destroy(gameObject);
        }
    }
}