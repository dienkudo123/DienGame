using System.Collections.Generic;
using UnityEngine;

namespace DienGame.Gameplay.Upgrades
{
    public static class LevelUpUpgradePool
    {
        private static readonly UpgradeDefinition[] Upgrades =
        {
            new(
                UpgradeType.Damage,
                "Tăng Sát Thương",
                "+20% sát thương",
                1.20f
            ),

            new(
                UpgradeType.MoveSpeed,
                "Tăng Tốc Chạy",
                "+15% tốc độ di chuyển",
                1.15f
            ),

            new(
                UpgradeType.MaxHealth,
                "Tăng Máu",
                "+25 HP tối đa",
                25f
            ),
        };

        public static List<UpgradeDefinition>
            GetRandomOptions(int count)
        {
            var available =
                new List<UpgradeDefinition>(Upgrades);

            var result =
                new List<UpgradeDefinition>();

            count = Mathf.Min(
                count,
                available.Count
            );

            for (int i = 0; i < count; i++)
            {
                int index =
                    Random.Range(
                        0,
                        available.Count
                    );

                result.Add(
                    available[index]
                );

                available.RemoveAt(index);
            }

            return result;
        }
    }
}