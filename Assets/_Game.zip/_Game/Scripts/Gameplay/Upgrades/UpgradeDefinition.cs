namespace DienGame.Gameplay.Upgrades
{
    public enum UpgradeType
    {
        Damage,
        MoveSpeed,
        MaxHealth,
    }

    public readonly struct UpgradeDefinition
    {
        public UpgradeType Type { get; }

        public string Title { get; }

        public string Description { get; }

        public float Value { get; }

        public UpgradeDefinition(
            UpgradeType type,
            string title,
            string description,
            float value)
        {
            Type = type;
            Title = title;
            Description = description;
            Value = value;
        }
    }
}