using DienGame.Gameplay.Player;
using UnityEngine;

namespace DienGame.Gameplay.Experience
{
    public sealed class ExperienceOrb : MonoBehaviour
    {
        [Header("Pickup")]
        [SerializeField]
        [Min(0f)]
        private float pickupRadius = 2.5f;

        [SerializeField]
        [Min(0.1f)]
        private float moveSpeed = 8f;

        [SerializeField]
        [Min(0.01f)]
        private float collectDistance = 0.15f;

        private PlayerExperience _playerExperience;
        private Transform _player;
        private int _experienceAmount;

        private bool _isAttracted;

        public void Initialize(int experienceAmount)
        {
            _experienceAmount =
                Mathf.Max(1, experienceAmount);
        }

        private void Start()
        {
            _playerExperience =
                FindFirstObjectByType<PlayerExperience>();

            if (_playerExperience == null)
            {
                Debug.LogError(
                    "ExperienceOrb: Không tìm thấy PlayerExperience.",
                    this
                );

                enabled = false;
                return;
            }

            _player =
                _playerExperience.transform;
        }

        private void Update()
        {
            if (_player == null)
                return;

            if (!_isAttracted)
            {
                CheckPickupRadius();
                return;
            }

            MoveTowardsPlayer();
        }

        private void CheckPickupRadius()
        {
            float distance =
                Vector2.Distance(
                    transform.position,
                    _player.position
                );

            if (distance <= pickupRadius)
            {
                _isAttracted = true;
            }
        }

        private void MoveTowardsPlayer()
        {
            transform.position =
                Vector3.MoveTowards(
                    transform.position,
                    _player.position,
                    moveSpeed * Time.deltaTime
                );

            float distance =
                Vector2.Distance(
                    transform.position,
                    _player.position
                );

            if (distance <= collectDistance)
            {
                Collect();
            }
        }

        private void Collect()
        {
            _playerExperience.AddExperience(
                _experienceAmount
            );

            Destroy(gameObject);
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.DrawWireSphere(
                transform.position,
                pickupRadius
            );
        }
    }
}