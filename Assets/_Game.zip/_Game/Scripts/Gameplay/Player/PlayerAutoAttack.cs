using DienGame.Gameplay.Combat;
using UnityEngine;

namespace DienGame.Gameplay.Player
{
    [RequireComponent(typeof(PlayerTargeting))]
    [RequireComponent(typeof(PlayerShootVisualSignal))]
    public sealed class PlayerAutoAttack : MonoBehaviour
    {
        [SerializeField] private PlayerCharacter playerCharacter;
        [SerializeField] private GameObject projectilePrefab;
        [SerializeField, Min(0f)] private float projectileSpawnDistance = 0.6f;

        [SerializeField, Min(0f)] private float attackDamage = 20f;
        [SerializeField, Min(0.01f)] private float attackInterval = 1f;

        private PlayerTargeting _targeting;
        private PlayerShootVisualSignal _shootSignal;
        private float _attackTimer;

        public float AttackDamage =>
            playerCharacter != null
                ? playerCharacter.Damage
                : attackDamage;

        private float AttackInterval =>
            playerCharacter != null
                ? playerCharacter.AttackInterval
                : attackInterval;

        private void Awake()
        {
            if (playerCharacter == null) playerCharacter = GetComponent<PlayerCharacter>();

            _targeting = GetComponent<PlayerTargeting>();
            _shootSignal = GetComponent<PlayerShootVisualSignal>();
        }

        private void Update()
        {
            if (_attackTimer > 0f) _attackTimer -= Time.deltaTime;
            TryAttack();
        }

        private void TryAttack()
        {
            if (_targeting == null || _targeting.CurrentTarget == null) return;
            if (_attackTimer > 0f) return;

            Shoot(_targeting.CurrentTarget);
            _attackTimer = AttackInterval;
        }

        private void Shoot(Transform target)
        {
            if (projectilePrefab == null || target == null) return;

            Vector2 direction =
                (Vector2)target.position -
                (Vector2)transform.position;

            if (direction.sqrMagnitude <= 0.0001f) return;

            direction.Normalize();

            Vector2 spawnPosition =
                (Vector2)transform.position +
                direction * projectileSpawnDistance;

            GameObject projectileObject =
                Instantiate(
                    projectilePrefab,
                    spawnPosition,
                    Quaternion.identity
                );

            if (projectileObject.TryGetComponent(out Projectile projectile))
            {
                projectile.Initialize(target, AttackDamage);
            }

            _shootSignal.TriggerShot();
        }

        public void MultiplyAttackDamage(float multiplier)
        {
            if (multiplier <= 0f) return;

            if (playerCharacter != null)
            {
                playerCharacter.MultiplyDamage(multiplier);
                return;
            }

            attackDamage *= multiplier;
        }
    }
}
