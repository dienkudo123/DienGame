using System.Collections.Generic;
using DienGame.Gameplay.Player;
using DienGame.Gameplay.Upgrades;
using UnityEngine;

namespace DienGame.Gameplay.Run
{
    public sealed class LevelUpController :
        MonoBehaviour
    {
        private PlayerExperience _experience;
        private PlayerMovement _movement;
        private PlayerAutoAttack _autoAttack;
        private PlayerHealth _health;

        private LevelUpUI _ui;

        private bool _isChoosingUpgrade;

        private void Start()
        {
            FindReferences();

            _experience.LeveledUp +=
                OnLeveledUp;
        }

        private void FindReferences()
        {
            _experience =
                FindFirstObjectByType<
                    PlayerExperience>();

            _movement =
                FindFirstObjectByType<
                    PlayerMovement>();

            _autoAttack =
                FindFirstObjectByType<
                    PlayerAutoAttack>();

            _health =
                FindFirstObjectByType<
                    PlayerHealth>();

            _ui =
                FindFirstObjectByType<
                    LevelUpUI>();

            if (_ui == null)
            {
                Canvas canvas =
                    FindFirstObjectByType<
                        Canvas>();

                if (canvas != null)
                {
                    _ui =
                        canvas.gameObject
                            .AddComponent<
                                LevelUpUI>();
                }
            }

            if (_experience == null)
            {
                Debug.LogError(
                    "Không tìm thấy PlayerExperience.",
                    this
                );
            }

            if (_movement == null)
            {
                Debug.LogError(
                    "Không tìm thấy PlayerMovement.",
                    this
                );
            }

            if (_autoAttack == null)
            {
                Debug.LogError(
                    "Không tìm thấy PlayerAutoAttack.",
                    this
                );
            }

            if (_health == null)
            {
                Debug.LogError(
                    "Không tìm thấy PlayerHealth.",
                    this
                );
            }

            if (_ui == null)
            {
                Debug.LogError(
                    "Không tìm thấy GameplayCanvas.",
                    this
                );
            }
        }

        private void OnLeveledUp(
            int newLevel)
        {
            if (_isChoosingUpgrade)
                return;

            OpenUpgradeSelection();
        }

        private void OpenUpgradeSelection()
        {
            if (_ui == null)
                return;

            _isChoosingUpgrade = true;

            Time.timeScale = 0f;

            List<UpgradeDefinition> options =
                LevelUpUpgradePool
                    .GetRandomOptions(3);

            _ui.Show(
                options,
                OnUpgradeSelected
            );

            Debug.Log(
                "LEVEL UP - game paused."
            );
        }

        private void OnUpgradeSelected(
            UpgradeDefinition upgrade)
        {
            ApplyUpgrade(upgrade);

            _ui.Hide();

            _isChoosingUpgrade = false;

            Time.timeScale = 1f;

            Debug.Log(
                $"Đã chọn: {upgrade.Title}"
            );
        }

        private void ApplyUpgrade(
            UpgradeDefinition upgrade)
        {
            switch (upgrade.Type)
            {
                case UpgradeType.Damage:
                    _autoAttack
                        .MultiplyAttackDamage(
                            upgrade.Value
                        );
                    break;

                case UpgradeType.MoveSpeed:
                    _movement
                        .MultiplyMoveSpeed(
                            upgrade.Value
                        );
                    break;

                case UpgradeType.MaxHealth:
                    _health
                        .AddMaxHealth(
                            upgrade.Value
                        );
                    break;
            }
        }

        private void OnDestroy()
        {
            if (_experience != null)
            {
                _experience.LeveledUp -=
                    OnLeveledUp;
            }
        }
    }
}